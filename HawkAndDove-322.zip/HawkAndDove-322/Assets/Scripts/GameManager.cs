﻿using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public Vector3 center;
    public GameObject hawkPrefab;
    public GameObject dovePrefab;
    public GameObject foodPrefab;
    public int min;
    public int max;
    private bool Switch = false;
    private int updateIndex = 0;
    public TMP_InputField hawkNum, doveNum, foodNum;
    public TMP_Dropdown population;
    public TMP_InputField foodValue, injury, bluffing, baseReq;
    public int foodValueInt, injuryInt, bluffingInt, baseReqInt;
    private DD_DataDiagram DataDiagram;
    private DD_DataDiagram m_DataDiagram;
    List<GameObject> lineList = new List<GameObject>();
    private float h = 0;
    public int index = 0;
    // Start is called before the first frame update
    void Start()
    {
        foodValueInt = System.Convert.ToInt32(foodValue.text);
        injuryInt = System.Convert.ToInt32(injury.text);
        bluffingInt = System.Convert.ToInt32(bluffing.text);
        baseReqInt = System.Convert.ToInt32(baseReq.text);
        GameObject dd = GameObject.Find("DataDiagram");
        if (null == dd)
        {
            Debug.LogWarning("can not find a gameobject of DataDiagram");
            return;
        }
        m_DataDiagram = dd.GetComponent<DD_DataDiagram>();

        m_DataDiagram.PreDestroyLineEvent += (s, e) => { lineList.Remove(e.line); };

        AddALine();
        AddALine();
        AddALine();
    }

    
    // Update is called once per frame
    void Update()
    {
        if (Switch)
        {
            if (updateIndex < 100)
            {
                Btn_Next_Click();
                updateIndex++;
            }
           else 
            {
                Switch = false;
            }
    
        }
    }
    public GameObject spawnPrefab(GameObject prefab)
    {
        Vector3 pos = center + new Vector3(Random.Range(min, max), Random.Range(min, max), 0);

        return Instantiate(prefab, pos, Quaternion.identity, transform);
    }
    public void Btn_Start_Click()
    {

        GameObject hawk = GameObject.Find("Hawk(Clone)");
        GameObject dove = GameObject.Find("Dove(Clone)");
        GameObject food = GameObject.Find("Food(Clone)");
        while (hawk)
        {
            GameObject.DestroyImmediate(hawk);
            hawk = GameObject.Find("Hawk(Clone)");
        }
        while (dove)
        {
            GameObject.DestroyImmediate(dove);
            dove = GameObject.Find("Dove(Clone)");
        }
        while (food)
        {
            GameObject.DestroyImmediate(food);
            food = GameObject.Find("Food(Clone)");
        }

        for (int i = 0; i < System.Convert.ToInt32(hawkNum.text); i++)
            spawnPrefab(hawkPrefab);

        for (int i = 0; i < System.Convert.ToInt32(doveNum.text); i++)
            spawnPrefab(dovePrefab);

        for (int i = 0; i < System.Convert.ToInt32(foodNum.text); i++)
            spawnPrefab(foodPrefab);
    }
    

    public void Btn_Next_Click()

    {
        List<GameObject> foods = new List<GameObject>();
        List<GameObject> hawks = new List<GameObject>();
        List<GameObject> doves = new List<GameObject>();
        List<GameObject> agents = new List<GameObject>();
        for (int i = 0; i < System.Convert.ToInt32(foodNum.text); i++)
        {
            spawnPrefab(foodPrefab);
        }
        foreach (GameObject hdf in GameObject.FindObjectsOfType(typeof(GameObject)))
        {
            if (hdf.name == "Food(Clone)")
            {
                foods.Add(hdf);
            }
            if (hdf.name == "Hawk(Clone)")
            {
                agents.Add(hdf);
                hawks.Add(hdf);
               
            }
            if (hdf.name == "Dove(Clone)")
            {
                agents.Add(hdf);
                doves.Add(hdf);
               
            }
        }
        while (agents!= null)
        {
            if (foods == null)
            {
                foreach (GameObject dh in agents)
                {
                    if (hawks.Contains(dh))
                    {
                        HawkManager hawk = dh.transform.GetComponent<HawkManager>();
                        hawk.energy = hawk.energy- baseReqInt;
                    }
                    else
                    {
                        DoveManager dove = dh.transform.GetComponent<DoveManager>();
                        dove.energy =dove.energy- baseReqInt;
                    }
                }
                break;
            }
            else
            {
                int r1 = Random.Range(1, agents.Count) - 1;
                int r2 = Random.Range(1, agents.Count) - 1;
                int r3 = Random.Range(1, foods.Count) - 1;
                if (agents.Count == 1)
                {
                    if (hawks.Contains(agents[0]))
                    {
                        HawkManager hawk = agents[0].transform.GetComponent<HawkManager>();
                        hawk.energy = hawk.energy + foodValueInt - baseReqInt;
                    }
                    if(doves.Contains(agents[0]))
                    {
                        DoveManager dove = agents[0].transform.GetComponent<DoveManager>();
                        dove.energy = dove.energy + foodValueInt - baseReqInt;
                    }
                    agents.RemoveAt(0);
                }
                else {
                    GameObject agent1 = agents[r1];
                    GameObject agent2 = agents[r2];
                    agents.RemoveAt(r1);
                    agents.RemoveAt(r2);
                    if (hawks.Contains(agent1) && hawks.Contains(agent2))
                    {
                        HawkManager hawk1 = agent1.transform.GetComponent<HawkManager>();
                        HawkManager hawk2 = agent2.transform.GetComponent<HawkManager>();
                        hawk1.energy = (foodValueInt - baseReqInt) + hawk1.energy;
                        hawk2.energy = hawk2.energy - (injuryInt + baseReqInt);
                    }
                    if (doves.Contains(agent1) && doves.Contains(agent2))
                    {
                        DoveManager dove1 = agent1.transform.GetComponent<DoveManager>();
                        DoveManager dove2 = agent2.transform.GetComponent<DoveManager>();
                        dove1.energy = (foodValueInt - bluffingInt - baseReqInt) + dove1.energy;
                        dove2.energy = dove2.energy - (bluffingInt + baseReqInt);
                    }
                    if (hawks.Contains(agent1) && doves.Contains(agent2))
                    {
                        HawkManager hawk = agent1.transform.GetComponent<HawkManager>();
                        DoveManager dove = agent2.transform.GetComponent<DoveManager>();
                        hawk.energy = foodValueInt + hawk.energy - baseReqInt;
                        dove.energy = dove.energy - baseReqInt;
                    }
                    if (doves.Contains(agent1) && hawks.Contains(agent2))
                    {
                        HawkManager hawk = agent2.transform.GetComponent<HawkManager>();
                        DoveManager dove = agent1.transform.GetComponent<DoveManager>();
                        hawk.energy = hawk.energy + foodValueInt - baseReqInt;
                        dove.energy = dove.energy - baseReqInt;
                    }

                }
                GameObject.DestroyImmediate(foods[r3]);
                foods.RemoveAt(0);
            } 
        }

        int howkCount = 0;
        int doveCount = 0;
        foreach (GameObject go in GameObject.FindObjectsOfType(typeof(GameObject)))
        {
            if (go.name == "Hawk(Clone)")
            {
                howkCount++;
            }
            else if (go.name == "Dove(Clone)")
            {
                doveCount++;
            }
        }

        Debug.Log(howkCount + "; " + doveCount);

        if (null == m_DataDiagram)
            return;

        int j = 0;
        foreach (GameObject l in lineList)
        {
            if (j == 0)
            {
                m_DataDiagram.InputPoint(l, new Vector2(1, (float)(howkCount / 10.0)));
            }
            else if (j == 1)
            {
                m_DataDiagram.InputPoint(l, new Vector2(1, (float)(doveCount / 10.0)));
            }
            else
            {
                m_DataDiagram.InputPoint(l, new Vector2(1, (float)((howkCount + doveCount) / 10.0)));
            }
            j++;
        }
    }

 

    public void createoffspring(string agent, int energy)
    {
        if (agent == "Hawk")
        {
            HawkManager hawk = spawnPrefab(hawkPrefab).GetComponent<HawkManager>();
            
        }
        if (agent == "Dove")
        {
            DoveManager dove = spawnPrefab(dovePrefab).GetComponent<DoveManager>();
        }
    }
    void AddALine()
    {

        if (null == m_DataDiagram)
            return;

        Color color = Color.HSVToRGB((h += 0.1f) > 1 ? (h - 1) : h, 0.8f, 0.8f);
        GameObject line = m_DataDiagram.AddLine(color.ToString(), color);
        if (null != line)
            lineList.Add(line);
    }

}
